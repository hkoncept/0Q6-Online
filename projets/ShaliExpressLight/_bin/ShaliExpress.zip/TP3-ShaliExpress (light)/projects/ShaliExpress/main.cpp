#include <conio.h>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numbers>
#include <string>
#include <vector>
#include <windows.h>

using namespace std;
namespace fs = std::filesystem;

const string PRODUCTS_FILE = "products_small.dat";  // Fichier qui sera utilisé pour la correction

class Product {
private:
	string code;
	string brand;
	string model;
	string description;
	float price;

public:
	Product() : code(""), brand(""), model(""), description(""), price(0.0f) {}

	void setCode(string code) { this->code = code; }
	void setBrand(string brand) { this->brand = brand; }
	void setModel(string model) { this->model = model; }
	void setDescription(string description) { this->description = description; }
	void setPrice(float price) { this->price = price; }

	string getCode() const { return this->code; }
	string getDescription() const { return this->description; }

	friend ostream& operator<<(ostream& os, const Product& p) {
		os << "| #" << p.code << " | " << setw(15) << left << p.brand << " | "
			<< setw(22) << left << p.model << " | " << setw(7) << right << fixed << setprecision(2) << p.price << "$ |";
		return os;
	}
};

const int TABLE_SIZE = 1500; // Nombre maximal d'éléments dans la table de hachage
template <typename T>
class StaticHashMap {
	// Votre code ici !
};

static long	loadProductsInMapFromFile(StaticHashMap<Product>& map, const string& filename) {
	ifstream file(filename);
	if (!file.is_open()) {
		cout << "Error opening file.\n";
		return -1;
	}
	long count = 0;
	string code;
	string data;
	while (!file.eof()) {
		Product product;
		getline(file, code, ',');
		product.setCode(code);
		getline(file, data, ',');
		product.setBrand(data);
		getline(file, data, ',');
		product.setModel(data);
		getline(file, data, ',');
		product.setDescription(data);
		getline(file, data);
		product.setPrice(stof(data));
		//map.put(code, product);
		count++;
	}
	file.close();
	return count;
}

static void runProductUpdateTest() {

	// #01 - Chargez les produits depuis le fichier et stockez-les dans une map

	// #02 - Sélectionnez un produit au hasard dans la map et affichez ses détails
		//cout << "Sélection aléatoire du produit #" << code << " dans la base de données" << endl;
		//cout << string(90, '-') << endl;
		//cout << setw(25) << left << "Original : ";

	// #03 - Modifiez la marque du produit sélectionné et affichez à nouveau les détails du produit
		//cout << setw(25) << left << "Modification locale :";

	// #04 - Allez chercher le même produit mais de la structure de données et affichez à nouveau les détails du produit
		//cout << setw(25) << left << "Original : ";
}


int main() {
	setlocale(LC_ALL, ".UTF-8");
	setlocale(LC_NUMERIC, "C");

	if (fs::exists(PRODUCTS_FILE)) {
		srand(clock());

		char input = 0;
		while (input != 27) {
			cout << "ShaliExpress (ESC pour quitter)  " << endl;
			cout << "----------------------------------------------" << endl;
			runProductUpdateTest();
			cout << endl << "Appuyez sur une touche pour lancer le test à nouveau..." << endl;
			input = _getch();
			system("cls");
		}
		cout << endl << "Programme terminé, appuyez sur une touche pour fermer..." << endl;
	}
	else {
		cerr << "Fichier de données : " << PRODUCTS_FILE << " introuvable [" << filesystem::current_path() << "]" << endl;
	}

	system("pause>nul");
	return 0;
}
